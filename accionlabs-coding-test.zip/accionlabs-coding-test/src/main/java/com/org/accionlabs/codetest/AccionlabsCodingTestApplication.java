package com.org.accionlabs.codetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccionlabsCodingTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccionlabsCodingTestApplication.class, args);
	}

}

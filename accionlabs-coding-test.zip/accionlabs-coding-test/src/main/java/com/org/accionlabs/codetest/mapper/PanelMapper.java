package com.org.accionlabs.codetest.mapper;

import com.org.accionlabs.codetest.entity.PanelDetails;
import com.org.accionlabs.codetest.model.PanelDetailsRequest;

public class PanelMapper {

	public static PanelDetails convertingPanelRequesttoEntityObject(PanelDetailsRequest request) {
		PanelDetails panelDetails=new PanelDetails();
		panelDetails.setPanelName(request.getPanelName());
		panelDetails.setTechStream(request.getTechStream());
		panelDetails.setDetailTechStack(request.getDetailTechStack());
		if(request.isFirstlevel()==true) {
		panelDetails.setFirstlevel("Yes");
		}
		else {
			panelDetails.setFirstlevel("no");
		}
		if(request.isSecondlevel()==true) {
			panelDetails.setSecondlevel("Yes");
			}
			else {
				panelDetails.setSecondlevel("no");
			}
		if(request.isManagerial()==true) {
			panelDetails.setManagerial("Yes");
			}
			else {
				panelDetails.setManagerial("no");
			}
		return panelDetails;
	}
	
	public static PanelDetails updatePanelDetails(PanelDetailsRequest request,PanelDetails panelDetails) {
	
		panelDetails.setPanelName(request.getPanelName());
		panelDetails.setTechStream(request.getTechStream());
		panelDetails.setDetailTechStack(request.getDetailTechStack());
		if(request.isFirstlevel()==true) {
		panelDetails.setFirstlevel("Yes");
		}
		else {
			panelDetails.setFirstlevel("no");
		}
		if(request.isSecondlevel()==true) {
			panelDetails.setSecondlevel("Yes");
			}
			else {
				panelDetails.setSecondlevel("no");
			}
		if(request.isManagerial()==true) {
			panelDetails.setManagerial("Yes");
			}
			else {
				panelDetails.setManagerial("no");
			}
		return panelDetails;
	}
	
}

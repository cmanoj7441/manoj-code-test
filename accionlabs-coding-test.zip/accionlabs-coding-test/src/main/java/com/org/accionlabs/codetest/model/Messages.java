package com.org.accionlabs.codetest.model;

public class Messages {

	
	public static final String DELETE_SUCCES_MESSAGE="deleted succesfully";
	
	public static final String CREATE_SUCCES_MESSAGE="deleted succesfully";
	
	public static final String ID_NOT_EXISTS="id not exist";
	
}

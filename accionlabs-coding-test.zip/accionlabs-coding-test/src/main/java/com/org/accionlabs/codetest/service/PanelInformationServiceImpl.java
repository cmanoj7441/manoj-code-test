package com.org.accionlabs.codetest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.accionlabs.codetest.entity.PanelDetails;
import com.org.accionlabs.codetest.exception.ResourceNotFoundException;
import com.org.accionlabs.codetest.mapper.PanelMapper;
import com.org.accionlabs.codetest.model.Messages;
import com.org.accionlabs.codetest.model.PanelDetailsRequest;
import com.org.accionlabs.codetest.repository.PanelRepository;

@Service
public class PanelInformationServiceImpl implements PanelInformationService{

	
	   @Autowired
	    private PanelRepository repository;
	
	@Override
	public void savePanelInformation(PanelDetails panelDetails) {
		repository.save(panelDetails);
		
	}

	@Override
	public List<PanelDetails> getAllPanelDetails() {
		return repository.findAll();
	}

	@Override
	public PanelDetails getPanelDetail(Integer id) {
	PanelDetails details=repository.findById(id).orElseThrow(() -> 
	new ResourceNotFoundException(Messages.ID_NOT_EXISTS + id));	
		return details;
	}

	@Override
	public PanelDetails updatePanelDetails(Integer id,PanelDetailsRequest request) {
		PanelDetails panelDetails=repository.findById(id).orElseThrow(() -> 
		new ResourceNotFoundException(Messages.ID_NOT_EXISTS + id));
		return repository.save(PanelMapper.updatePanelDetails(request, panelDetails));
	}

	@Override
	public void deletePanelInformation(Integer id) {
		PanelDetails panelDetails= repository.findById(id).orElseThrow(() -> 
		new ResourceNotFoundException(Messages.ID_NOT_EXISTS + id));
		repository.delete(panelDetails);
	}

}

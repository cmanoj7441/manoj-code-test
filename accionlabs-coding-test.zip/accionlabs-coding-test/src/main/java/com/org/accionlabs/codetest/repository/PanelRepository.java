package com.org.accionlabs.codetest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.accionlabs.codetest.entity.PanelDetails;

public interface PanelRepository extends JpaRepository<PanelDetails, Integer> {

}

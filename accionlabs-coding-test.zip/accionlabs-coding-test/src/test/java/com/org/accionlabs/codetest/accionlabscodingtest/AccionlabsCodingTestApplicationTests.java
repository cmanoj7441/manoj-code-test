package com.org.accionlabs.codetest.accionlabscodingtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccionlabsCodingTestApplicationTests {

	@Test
	void contextLoads() {
	}

}

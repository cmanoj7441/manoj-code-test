package com.org.accionlabs.codetest.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PanelDetailsRequest {

	private String panelName;
	
	private String techStream;
	
	private String detailTechStack;
	
	private boolean firstlevel;
	
	private boolean secondlevel;
	
	private boolean  managerial; 
	
	
}

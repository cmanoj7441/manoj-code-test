package com.org.accionlabs.codetest.service;

import java.util.List;

import com.org.accionlabs.codetest.entity.PanelDetails;
import com.org.accionlabs.codetest.model.PanelDetailsRequest;

public interface PanelInformationService {

	
	public void savePanelInformation(PanelDetails panelDetails);
		
	public List<PanelDetails> getAllPanelDetails();
	
	public PanelDetails getPanelDetail(Integer id);
		
	public PanelDetails updatePanelDetails(Integer id,PanelDetailsRequest request);
	
	public void deletePanelInformation(Integer id);
	
	}
	


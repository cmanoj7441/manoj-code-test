
package com.org.accionlabs.codetest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "panel")
public class PanelDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "panel_id")
	private int id;
	
	@Column(name = "panel_name")
	private String panelName;
	
	@Column(name = "tech_stream")
	private String techStream;
	
	@Column(name = "detail_techstack")
	private String detailTechStack;

	@Column(name = "firstlevel")
	private String  firstlevel;
	
	@Column(name = "secondlevel")
	private String  secondlevel;
	
	@Column(name = "managerial")
	private String   managerial; 

}

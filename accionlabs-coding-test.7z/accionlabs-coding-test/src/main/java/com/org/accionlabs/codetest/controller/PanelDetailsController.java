package com.org.accionlabs.codetest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.accionlabs.codetest.entity.PanelDetails;
import com.org.accionlabs.codetest.mapper.PanelMapper;
import com.org.accionlabs.codetest.model.Messages;
import com.org.accionlabs.codetest.model.PanelDetailsRequest;
import com.org.accionlabs.codetest.service.PanelInformationService;

@RestController
@RequestMapping("/api/v1")
public class PanelDetailsController {

	@Autowired
	PanelInformationService panelInformationService;

	
	
	

	
	
	@PostMapping("/accion-labs/panel")
	public String  savePanelInformation(@RequestBody PanelDetailsRequest panelDetailsRequest) {
		panelInformationService
				.savePanelInformation(PanelMapper.convertingPanelRequesttoEntityObject(panelDetailsRequest));

		return Messages.CREATE_SUCCES_MESSAGE;
		
	}


	@GetMapping("/accion-labs/panel")
	public List<PanelDetails> getAllPanelInformation() {
		return panelInformationService.getAllPanelDetails();
	}

	@GetMapping("/accion-labs/panel/{id}")
	public ResponseEntity<PanelDetails> getPanelInformation(@PathVariable(value = "id") Integer id) {
		
		return ResponseEntity.ok().body(panelInformationService.getPanelDetail(id));
	}
	
	@PutMapping("/accion-labs/panel/{id}")
	public ResponseEntity<PanelDetails> updatePanelDetails(@PathVariable(value = "id") Integer id,
			 @RequestBody PanelDetailsRequest request) {
		
		return ResponseEntity.ok(panelInformationService.updatePanelDetails(id, request));
	}

	@DeleteMapping("/accion-labs/panel/{id}")
	public String deletePanelInformation(@PathVariable(value = "id") Integer id) {

		panelInformationService.deletePanelInformation(id);
		
	    return 	Messages.DELETE_SUCCES_MESSAGE;
	}

}
